# Extract text subtitle streams to SRT files with ISO codes

plugin for [Unmanic](https://github.com/Unmanic)

For more information on external subtitle Files
    - [Jellyfin: External Subtitles](https://jellyfin.org/docs/general/server/media/external-files)
    - [Plex: Local Subtitles](https://support.plex.tv/articles/200471133-adding-local-subtitles-to-your-media/)
    - [Kodi: Subtitles](https://kodi.wiki/view/Subtitles#Using_multi_language_subtitles)