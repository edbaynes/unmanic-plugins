**<span style="color:#56adda">0.0.2</span>**
- Using Python Babelfish package for language code conversion
- Added Option to use OpenSubtitles naming codes
- Added Option to choose prefered Latin American Spanish extension

**<span style="color:#56adda">0.0.1</span>**
- Extract subtitles using hard coded ISO 639-1 codes
- Based on Extract text subtitle streams to SRT files v0.0.8
